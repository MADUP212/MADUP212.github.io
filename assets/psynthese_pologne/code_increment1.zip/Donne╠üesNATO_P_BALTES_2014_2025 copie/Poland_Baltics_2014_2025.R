# ===================================================================
# ANALYSE DE L'ÉVOLUTION DES CAPACITÉS MILITAIRES
# Auteur: [Votre Nom]
# Date: 26 septembre 2025
# ===================================================================


# -------------------------------------------------------------------
# 1. PRÉPARATION : CHARGEMENT DES LIBRAIRIES
# -------------------------------------------------------------------
# Le tidyverse pour la manipulation de données (dplyr, tidyr) et la visualisation (ggplot2)
library(tidyverse) 
# Le paquet scales pour un formatage avancé des axes des graphiques
library(scales)   


# -------------------------------------------------------------------
# 2. PRÉPARATION : FONCTION DE NETTOYAGE DES DONNÉES
# -------------------------------------------------------------------
# Cette fonction prend en entrée un tableau de données de l'OTAN au format "large"
# et le retourne au format "long", prêt pour la visualisation.
#
# Arguments :
#   df_wide : Le tableau de données original (ex: mil_dollars).
#   nom_valeur : Le nom que l'on veut donner à la colonne des valeurs (ex: "Depenses_USD").
#
clean_nato_data <- function(df_wide, nom_valeur) {
  df_wide %>%
    # Renomme la première colonne (qui contient les pays) en "Pays" pour la standardisation.
    rename(Pays = 1) %>% 
    
    # Pivote les colonnes qui commencent par "X" (les années) en un format long.
    pivot_longer(
      cols = starts_with("X"),
      names_to = "Annee",
      values_to = "Valeur" # Nom de colonne temporaire
    ) %>%
    
    # Nettoie les données et renomme la colonne de valeurs.
    mutate(
      Annee = as.numeric(gsub("e", "", gsub("X", "", Annee))),
      Valeur = as.numeric(gsub(",", ".", Valeur))
    ) %>%
    
    # Renomme la colonne de valeurs avec le nom fourni en argument.
    rename({{ nom_valeur }} := Valeur)
}


# -------------------------------------------------------------------
# 3. IMPORTATION DES DONNÉES
# -------------------------------------------------------------------
# NOTE : Les fichiers CSV doivent être dans le même dossier que votre script R,
# ou dans un sous-dossier (ex: "data/military_dollars.csv").
# L'utilisation de chemins relatifs rend votre projet partageable et reproductible.

mil_dollars <- read.csv("military_dollars.csv")
mil_gdp     <- read.csv("military_gdp.csv")
mil_troops  <- read.csv("military_troops.csv")


# -------------------------------------------------------------------
# 4. TRANSFORMATION DES DONNÉES
# -------------------------------------------------------------------
# On applique notre fonction de nettoyage à chaque jeu de données.

df_dollars_long <- clean_nato_data(mil_dollars, "Depenses_USD")
df_gdp_long     <- clean_nato_data(mil_gdp, "Pourcentage_PIB")
df_troops_long  <- clean_nato_data(mil_troops, "Effectifs_milliers")


# -------------------------------------------------------------------
# 5. VISUALISATION DES DONNÉES
# -------------------------------------------------------------------

# --- Graphique 1 : Dépenses militaires en millions de $ (tous les pays) ---
ggplot(data = df_dollars_long, aes(x = Annee, y = Depenses_USD, color = Pays)) +
  geom_line(linewidth = 1.2) +
  geom_point(size = 2.5) +
  scale_y_continuous(labels = label_comma()) +
  labs(
    title = "Évolution des dépenses militaires, 2014-2025",
    subtitle = "En millions de $ (USD constant)",
    x = "Année", y = "Dépenses (en millions de $ USD)", color = "Pays"
  ) +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5),
        legend.position = "bottom")

# --- Graphique 2 : Dépenses militaires en millions de $ (États baltes uniquement) ---
df_dollars_long %>%
  filter(Pays != "Pologne") %>%
  ggplot(aes(x = Annee, y = Depenses_USD, color = Pays)) +
  geom_line(linewidth = 1.2) +
  geom_point(size = 2.5) +
  scale_y_continuous(labels = label_comma()) +
  labs(
    title = "Évolution des dépenses militaires des États baltes, 2014-2025",
    subtitle = "En millions de $ (USD constant)",
    x = "Année", y = "Dépenses (en millions de $ USD)", color = "Pays"
  ) +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5),
        legend.position = "bottom")

# --- Graphique 3 : Dépenses militaires en % du PIB ---
ggplot(data = df_gdp_long, aes(x = Annee, y = Pourcentage_PIB, color = Pays)) +
  geom_line(linewidth = 1.2) +
  geom_point(size = 2.5) +
  scale_y_continuous(labels = scales::percent_format(scale = 1, accuracy = 0.1)) +
  labs(
    title = "Évolution des dépenses militaires en % du PIB, 2014-2025",
    subtitle = "e = estimations",
    x = "Année", y = "Dépenses militaires (% du PIB)", color = "Pays"
  ) +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5),
        legend.position = "bottom")

# --- Graphique 4 : Effectifs militaires (tous les pays) ---
ggplot(data = df_troops_long, aes(x = Annee, y = Effectifs_milliers, color = Pays)) +
  geom_line(linewidth = 1.2) +
  geom_point(size = 2.5) +
  scale_y_continuous(labels = label_comma()) +
  labs(
    title = "Évolution des effectifs militaires, 2014-2025",
    subtitle = "En milliers (e = estimations)",
    x = "Année", y = "Effectifs (en milliers)", color = "Pays"
  ) +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5),
        legend.position = "bottom")

# --- Graphique 5 : Effectifs militaires (États baltes uniquement) ---
df_troops_long %>%
  filter(Pays != "Pologne") %>%
  ggplot(aes(x = Annee, y = Effectifs_milliers, color = Pays)) +
  geom_line(linewidth = 1.2) +
  geom_point(size = 2.5) +
  scale_y_continuous(labels = label_comma()) +
  labs(
    title = "Évolution des effectifs militaires des États baltes, 2014-2025",
    subtitle = "En milliers (e = estimations)",
    x = "Année", y = "Effectifs (en milliers)", color = "Pays"
  ) +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5),
        legend.position = "bottom")